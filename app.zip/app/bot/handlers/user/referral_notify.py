"""
Yangi referral kelganda referrerga xabar yuborish.

Xabar tarkibi:
1. Admin tomonidan yozilgan matn (contest.referral_message) — agar bo'lsa
2. Konkurs haqida to'liq ma'lumot
3. Inline button → botga o'tish (do'stning referral havolasi)
"""
import logging

from aiogram import Bot
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from sqlalchemy.ext.asyncio import AsyncSession

from app.repositories.contest_repo import ContestRepository
from app.repositories.user_repo import UserRepository

logger = logging.getLogger(__name__)


async def notify_referrer(
    bot: Bot,
    referrer_telegram_id: int,
    new_user_name: str,
    db: AsyncSession,
) -> None:
    """
    Referrer yangi do'st taklif qilganda xabar yuborish.

    Parametrlar:
    - referrer_telegram_id: kim referral qildi (unga xabar ketadi)
    - new_user_name: yangi kelgan foydalanuvchi ismi
    - db: database session
    """
    contest_repo = ContestRepository(db)
    contest = await contest_repo.get_active_contest()

    user_repo = UserRepository(db)
    referrer = await user_repo.get_by_telegram_id(referrer_telegram_id)
    if not referrer:
        return

    ref_count = referrer.referral_count
    target = contest.required_referrals if contest else 5
    remaining = max(0, target - ref_count)
    prize_name = (contest.prize_channel_title or "Prize Kanal") if contest else "Prize Kanal"

    # ── Matn tarkibi ────────────────────────────────────────────────────────
    text_parts = []

    # 1. Admin tomonidan yozilgan maxsus referral xabari (agar mavjud bo'lsa)
    if contest and getattr(contest, "referral_message", None):
        text_parts.append(contest.referral_message)
        text_parts.append("")  # bo'sh qator

    # 2. Avtomatik xabar
    text_parts.append(f"🎉 <b>{new_user_name}</b> sizning havolangiz orqali qo'shildi!")
    text_parts.append("")

    if contest:
        text_parts.append(f"🏆 <b>Konkurs:</b> {contest.title}")
        text_parts.append(f"📊 Sizning natijangiz: <b>{ref_count}/{target}</b>")

        if remaining > 0:
            text_parts.append(f"🎯 Yana <b>{remaining} ta</b> do'st kerak → <b>{prize_name}</b>!")
        else:
            text_parts.append(f"✅ Shartni bajardingiz! <b>{prize_name}</b> havolasi yuborilmoqda...")

    full_text = "\n".join(text_parts)

    # ── Keyboard ─────────────────────────────────────────────────────────────
    bot_info = await bot.get_me()
    bot_username = bot_info.username

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="🔗 Yana do'st taklif qilish ↗",
            url=f"https://t.me/{bot_username}?start={referrer_telegram_id}"
        )],
    ])

    try:
        await bot.send_message(
            chat_id=referrer_telegram_id,
            text=full_text,
            reply_markup=keyboard,
            parse_mode="HTML",
            disable_web_page_preview=True,
        )
        logger.info(f"Referral notify yuborildi: referrer={referrer_telegram_id}, new_user={new_user_name}")
    except Exception as e:
        logger.error(f"Referral notify xatolik (referrer={referrer_telegram_id}): {e}")
