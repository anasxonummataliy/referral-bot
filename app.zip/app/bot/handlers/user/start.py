"""
/start handler + obuna tekshiruvi
"""

import asyncio
import logging

from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery, BotCommand
from aiogram.filters import CommandStart
from aiogram.utils.deep_linking import decode_payload
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.commands import setup_bot_commands
from app.core.config import settings
from app.services.subscription_service import SubscriptionService
from app.services.referral_service import ReferralService
from app.repositories.user_repo import UserRepository
from app.repositories.contest_repo import ContestRepository
from app.bot.handlers.admin.base import is_admin_async, admin_main_keyboard
from app.bot.handlers.user.utils import safe_send_message, safe_answer, progress_bar
from app.bot.handlers.user.keyboards import main_menu_keyboard, subscription_keyboard
from app.bot.handlers.user.prize import check_and_send_prize
from app.bot.handlers.user.referral_notify import notify_referrer

logger = logging.getLogger(__name__)
router = Router()

# ── Animatsiya (faqat /start uchun) ──────────────────────────────────────────
PROGRESS_FRAMES = [
    "⬜⬜⬜⬜⬜  0%",
    "🟩⬜⬜⬜⬜ 20%",
    "🟩🟩⬜⬜⬜ 40%",
    "🟩🟩🟩⬜⬜ 60%",
    "🟩🟩🟩🟩⬜ 80%",
    "🟩🟩🟩🟩🟩 100% ✅",
]


async def _loading_animation(message: Message) -> None:
    try:
        anim = await message.answer("⏳ Yuklanmoqda...")
        for frame in PROGRESS_FRAMES:
            await asyncio.sleep(0.22)
            try:
                await anim.edit_text(frame)
            except Exception:
                pass
        await asyncio.sleep(0.15)
        try:
            await anim.delete()
        except Exception:
            pass
    except Exception:
        pass


# ── Bot commandlarini o'rnatish ───────────────────────────────────────────────
async def set_bot_commands(bot: Bot) -> None:
    commands = [
        BotCommand(command="start", description="🏠 Bosh menyu"),
        BotCommand(command="referral", description="🔗 Mening taklif havolam"),
        BotCommand(command="mystats", description="📊 Mening natijam"),
        BotCommand(command="help", description="❓ Yordam"),
    ]
    try:
        await bot.set_my_commands(commands)
        logger.info("✅ Bot commandlari o'rnatildi")
    except Exception as e:
        logger.error(f"Bot commandlarini o'rnatishda xatolik: {e}")


# ── Asosiy menyu ─────────────────────────────────────────────────────────────
async def show_main_menu(
    message: Message,
    db: AsyncSession,
    contest,
    edit: bool = False,
) -> None:
    user_id = message.from_user.id
    sub_service = SubscriptionService(db)

    # Obuna tekshiruvi
    is_subscribed = await sub_service.check_full_subscription(
        bot=message.bot, telegram_id=user_id
    )
    if not is_subscribed:
        channels = await sub_service.get_required_channels()
        keyboard = subscription_keyboard(channels)
        text = (
            "👋 <b>Assalomu alaykum!</b>\n\n"
            "🔐 Botdan foydalanish uchun quyidagi kanallarga a'zo bo'ling:\n\n"
            "A'zo bo'lgach <b>✅ Obunani tekshirish</b> tugmasini bosing."
        )
        if edit:
            try:
                await message.edit_text(text, reply_markup=keyboard)
            except Exception:
                await message.answer(text, reply_markup=keyboard)
        else:
            await message.answer(text, reply_markup=keyboard)
        return

    # Referral link
    bot_info = await message.bot.get_me()
    bot_username = settings.BOT_USERNAME or bot_info.username
    ref_service = ReferralService(db)
    referral_link = await ref_service.get_user_referral_link(
        telegram_id=user_id, bot_username=bot_username
    )

    user_repo = UserRepository(db)
    user = await user_repo.get_by_telegram_id(user_id)
    ref_count = user.referral_count if user else 0
    target = contest.required_referrals if contest else 5
    bar = progress_bar(ref_count, target)
    name = message.from_user.first_name or "Foydalanuvchi"

    text = (
        f"👋 <b>Xush kelibsiz, {name}!</b>\n\n"
        f"🏆 <b>Konkurs:</b> {contest.title}\n"
        f"🎯 Maqsad: <b>{target} ta</b> do'st taklif qiling\n\n"
        f"📊 <b>Sizning natijangiz:</b>\n"
        f"✅ Tasdiqlangan: <b>{ref_count} ta</b>\n\n"
        f"{bar}\n\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"🔗 <b>Sizning havolangiz:</b>\n"
        f"<code>{referral_link}</code>"
    )

    if edit:
        try:
            await message.edit_text(
                text, reply_markup=main_menu_keyboard(), disable_web_page_preview=True
            )
        except Exception:
            await message.answer(
                text, reply_markup=main_menu_keyboard(), disable_web_page_preview=True
            )
    else:
        await message.answer(
            text, reply_markup=main_menu_keyboard(), disable_web_page_preview=True
        )


# ── /start ────────────────────────────────────────────────────────────────────
@router.message(CommandStart())
async def cmd_start(message: Message, bot: Bot, db: AsyncSession):
    user_id = message.from_user.id

    # Admin → admin panel
    if await is_admin_async(user_id, db):
        name = message.from_user.first_name or "Admin"
        await message.answer(
            f"🛡 <b>Xush kelibsiz, {name}!</b>\n\n"
            "🔑 <b>Admin Panel</b>\n\nQuyidagi bo'limlardan birini tanlang:",
            reply_markup=admin_main_keyboard(),
        )
        return

    # Referral payload
    referrer_id = None
    if message.text and len(message.text.split()) > 1:
        args = message.text.split()[1]
        try:
            payload = decode_payload(args)
            if payload.isdigit():
                referrer_id = int(payload)
        except Exception:
            if args.isdigit():
                referrer_id = int(args)

    # User yaratish / olish
    user_repo = UserRepository(db)
    _, is_new = await user_repo.get_or_create(
        telegram_id=user_id,
        full_name=message.from_user.full_name,
        username=message.from_user.username,
        language_code=message.from_user.language_code,
    )

    # Yangi user + referrer → referral qayd
    if is_new and referrer_id and referrer_id != user_id:
        ref_service = ReferralService(db)
        await ref_service.process_new_referral(
            new_user_telegram_id=user_id,
            referrer_telegram_id=referrer_id,
        )
        # Referrerga bildirishnoma (admin matni + konkurs info + inline button)
        await notify_referrer(
            bot=message.bot,
            referrer_telegram_id=referrer_id,
            new_user_name=message.from_user.first_name or "Do'st",
            db=db,
        )
        # Referrerga prize link tekshirish (shartni bajirdimi?)
        await check_and_send_prize(
            bot=message.bot,
            referrer_telegram_id=referrer_id,
            db=db,
        )

    # Konkursni olish
    contest_repo = ContestRepository(db)
    contest = await contest_repo.get_active_contest()

    # Animatsiya (faqat /start message uchun)
    await _loading_animation(message)

    if not contest:
        await message.answer(
            "🤖 <b>Assalomu alaykum!</b>\n\n"
            "⏳ Hozircha aktiv konkurs yo'q.\n\n"
            "Tez orada yangi konkurs e'lon qilinadi — kuzatib boring! 👀"
        )
        return

    # Kirish xabari (welcome message)
    if contest.welcome_message:
        await safe_send_message(message, contest.welcome_message)

    await show_main_menu(message, db, contest)


# ── Obunani tekshirish ────────────────────────────────────────────────────────
@router.callback_query(F.data == "check_subscription")
async def check_subscription_cb(callback: CallbackQuery, db: AsyncSession):
    # ✅ BIRINCHI callback.answer() — 30s timeout oldini olish
    user_id = callback.from_user.id
    sub_service = SubscriptionService(db)

    is_subscribed = await sub_service.check_full_subscription(
        bot=callback.bot, telegram_id=user_id
    )

    if is_subscribed:
        await safe_answer(callback, "✅ Obuna tasdiqlandi!")
        try:
            await callback.message.delete()
        except Exception:
            pass

        contest_repo = ContestRepository(db)
        contest = await contest_repo.get_active_contest()

        if not contest:
            await callback.message.answer(
                "⏳ Hozircha aktiv konkurs yo'q.\n\nTez orada e'lon qilinadi!"
            )
            return

        await show_main_menu(callback.message, db, contest)
    else:
        await safe_answer(
            callback,
            "❌ Siz hali barcha kanallarga a'zo bo'lmagansiz!",
            show_alert=True,
        )


# ── Orqaga ────────────────────────────────────────────────────────────────────
@router.callback_query(F.data == "back_to_main")
async def back_to_main_cb(callback: CallbackQuery, db: AsyncSession):
    await safe_answer(callback)

    if await is_admin_async(callback.from_user.id, db):
        await callback.message.edit_text(
            "🛠 <b>Admin Panel</b>\n\nQuyidagi bo'limlardan birini tanlang:",
            reply_markup=admin_main_keyboard(),
        )
        return

    contest_repo = ContestRepository(db)
    contest = await contest_repo.get_active_contest()

    if not contest:
        await callback.message.edit_text(
            "⏳ Hozircha aktiv konkurs yo'q.\n\nTez orada e'lon qilinadi!"
        )
        return

    await show_main_menu(callback.message, db, contest, edit=True)


# ── /admin command ────────────────────────────────────────────────────────────
from aiogram.filters import Command as _Command


@router.message(_Command("admin"))
async def cmd_admin(message: Message, db: AsyncSession):
    if not await is_admin_async(message.from_user.id, db):
        return
    name = message.from_user.first_name or "Admin"
    await message.answer(
        f"🛡 <b>Xush kelibsiz, {name}!</b>\n\n"
        "🔑 <b>Admin Panel</b>\n\nQuyidagi bo'limlardan birini tanlang:",
        reply_markup=admin_main_keyboard(),
    )
