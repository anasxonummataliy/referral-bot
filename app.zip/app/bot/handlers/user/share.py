"""
Havolani ulashish + Referral xabari (admin matni + konkurs info + inline button)
"""
import logging
import urllib.parse

from aiogram import Router, F
from aiogram.types import (
    Message, CallbackQuery,
    InlineKeyboardMarkup, InlineKeyboardButton,
)
from aiogram.filters import Command
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.services.referral_service import ReferralService
from app.repositories.contest_repo import ContestRepository
from app.bot.handlers.user.utils import safe_answer
from app.bot.handlers.user.keyboards import back_keyboard

logger = logging.getLogger(__name__)
router = Router()


def _share_keyboard(referral_link: str, contest_title: str, bot_username: str) -> InlineKeyboardMarkup:
    """
    Havolani ulashish + botga o'tish tugmasi.
    Referral qilingan do'stga: admin matni + konkurs haqida + shu tugma
    """
    encoded_link = urllib.parse.quote(referral_link, safe="")
    share_text = urllib.parse.quote(
        f"🎁 Do'stim, bu botda ajoyib konkurs bor!\n"
        f"Ishtirok etish uchun quyidagi havolani bos 👇",
        safe=""
    )
    share_url = f"https://t.me/share/url?url={encoded_link}&text={share_text}"

    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📤 Do'stlarga ulashish ↗", url=share_url)],
        [InlineKeyboardButton(text="🔙 Orqaga", callback_data="back_to_main")],
    ])


@router.callback_query(F.data == "share_link")
async def share_link_cb(callback: CallbackQuery, db: AsyncSession):
    await safe_answer(callback)

    user_id = callback.from_user.id
    bot_info = await callback.bot.get_me()
    bot_username = settings.BOT_USERNAME or bot_info.username

    ref_service = ReferralService(db)
    referral_link = await ref_service.get_user_referral_link(
        telegram_id=user_id, bot_username=bot_username
    )

    contest_repo = ContestRepository(db)
    contest = await contest_repo.get_active_contest()
    target = contest.required_referrals if contest else 5

    text = (
        f"🔗 <b>Sizning taklif havolangiz:</b>\n\n"
        f"<code>{referral_link}</code>\n\n"
        f"🎯 Maqsad: <b>{target} ta</b> do'st taklif qiling\n"
        f"🎁 Mukofot: Prize kanalga <b>1 martalik</b> kirish!\n\n"
        f"📤 Havolani do'stlaringizga yuboring!"
    )

    keyboard = _share_keyboard(referral_link, contest.title if contest else "", bot_username)
    await callback.message.edit_text(text, reply_markup=keyboard, disable_web_page_preview=True)


@router.message(Command("referral", "link"))
async def cmd_referral(message: Message, db: AsyncSession):
    user_id = message.from_user.id
    bot_info = await message.bot.get_me()
    bot_username = settings.BOT_USERNAME or bot_info.username

    ref_service = ReferralService(db)
    referral_link = await ref_service.get_user_referral_link(
        telegram_id=user_id, bot_username=bot_username
    )

    encoded_link = urllib.parse.quote(referral_link, safe="")
    share_text = urllib.parse.quote(
        "🎁 Do'stim, bu botda ajoyib konkurs bor!\nIshtirok etish uchun quyidagi havolani bos 👇",
        safe=""
    )
    share_url = f"https://t.me/share/url?url={encoded_link}&text={share_text}"

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📤 Ulashish ↗", url=share_url)],
    ])
    await message.answer(
        f"🔗 <b>Sizning taklif havolangiz:</b>\n\n<code>{referral_link}</code>",
        reply_markup=keyboard,
        disable_web_page_preview=True,
    )
